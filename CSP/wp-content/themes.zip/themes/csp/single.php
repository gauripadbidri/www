<?php get_header(); ?>
	<section id="body" class="singleNews">
    <section class="col-md-offset-1 col-lg-10 col-md-10">
        <!--<div id="image-section" class=" col-lg-10 col-md-7 img-responsive">
        </div>-->
        <div class="col-lg-3 col-md-3">
        </div>
    </section>
    <section class="col-md-offset-1 col-lg-10 col-md-10 bgColor">
        <div>
<h1><?php the_title(); ?></h1>
          <div class="col-lg-12 col-md-12" style="background:whitesmoke; height:2px;"></div>
          <br/>
<?php if ( have_posts() ) while ( have_posts() ) : the_post(); ?>
          <span>
            <?php the_content( __( '', 'wpbootstrap' ) ); ?>
          </span>
<?php endwhile; ?>
        </div>
    </section>
    <section>
        <div>

        </div>
    </section>
</section>
<?php get_footer(); ?>