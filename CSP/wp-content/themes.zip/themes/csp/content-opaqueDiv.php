<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

?>

<div id="open_close" class="col-md-4 col-lg-4 col-sm-4 col-xm-4">
    <span class="close-container"><p style="color:black;">CSP Networks</p></span>
    <div class="open-container">
        <span class="testimonial"><span id="playicon"></span>
          <a href="#"><span style="color:black !important;">Play Testimonial</span>
          </a>
        </span>
        <span class="case_study">
          <a href="#">
            <p style="color:black;"> Case Study </p>
          </a> </span>
    </div>
</div>