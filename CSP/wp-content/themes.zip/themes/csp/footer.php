

</div>
 
<script type="text/javascript" src="<?php echo get_stylesheet_directory_uri(); ?>/script.js"></script>
<script type="text/javascript" src="<?php echo get_stylesheet_directory_uri(); ?>/bootstrap/js/bootstrap.min.js">
</script>
</body>


</html>

