<?php
/*
  Template Name: Cloud
 * MultiEdit: CloudImageText,Row1Col1Text,Row1Col2Text,Row2Col1Text,Row2Col2Text
 */
?>

<?php get_header(); ?>
<section id="body">
    <div class="container cloud">
        
        <!-- upper image container -->
        <section id="datatitle" class="col-lg-12 col-md-12">
            <div class="col-lg-12 col-md-12" style="background:whitesmoke; height:5px"></div>
            <div id="image-section" class="col-lg-6 col-md-6 col-sm-12 col-xs-12" style="padding: 0px;">
                <img id="retail-img" class="img-responsive" src="<?php echo get_stylesheet_directory_uri(); ?>/images/Cloud_Closed_img1.jpg" />
                <?php get_template_part('content', 'opaqueDiv');?>
            </div>
            <div style="background-color: #5590cc;" class="col-lg-6 col-md-6 col-sm-12 col-xs-12 imageInfoSection">
                <p>
                    <h3><?php echo rwmb_meta('meta_CloudImageHeader'); ?></h3>
                </p>
                <span style="color: white;">
                   <?php multieditDisplay("CloudImageText") ?>  
                </span>
            </div>
            <div class="col-lg-12 col-md-12" style="background:whitesmoke; height:5px"></div>
        </section>
        <section id="datadescription"  class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <div class="row datacontainer ">
                <section  class="col-md-6 col-lg-6 col-sm-12 col-xs-12 sectiondata">
                    <div class="title">
                      <span class="vAlignCenter"><?php echo rwmb_meta('meta_Row1Col1Text'); ?></span>
                    </div>
                    <div> <?php multieditDisplay("Row1Col1Text") ?> </div>
                </section>
                <section class="col-md-6 col-lg-6 col-sm-12 col-xs-12 sectiondata">
                    <div class="title">
                      <span class="vAlignCenter"><?php echo rwmb_meta('meta_Row1Col2Text'); ?></span>
                    </div>
                    <div><?php multieditDisplay("Row1Col2Text") ?></div>
                </section>
            </div>
            <div class="row datacontainer ">
                <section class="col-md-6 col-lg-6 col-sm-12 col-xs-12 sectiondata">
                    <div class="title">
                      <span class="vAlignCenter"><?php echo rwmb_meta('meta_Row2Col1Text'); ?></span>
                    </div>
                    <div><?php multieditDisplay("Row2Col1Text") ?></div>
                </section>
                <section class="col-md-6 col-lg-6 col-sm-12 col-xs-12 sectiondata">
                    <div class="title">
                      <span class="vAlignCenter"><?php echo rwmb_meta('meta_Row2Col2Text'); ?></span>
                    </div>
                    <div><?php multieditDisplay("Row2Col2Text") ?></div>
                </section>
            </div>
        </section>
</div>
</section>
<?php get_footer(); ?>